import ReviewCard from "./ReviewCard";
import { reviews } from "@/data/content";
import { u, P } from "@/lib/u";

export default function Testimonials() {
  // 3 copies so the automatic slide loops seamlessly (see .reviews-track in globals.css)
  const loop = [...reviews, ...reviews, ...reviews];
  return (
    <section id="reviews" className="relative w-full overflow-hidden bg-linear-to-b from-[#55534d] to-[#262626]" style={{ height: u(433) }}>
      <svg className="absolute inset-0 size-full" viewBox="0 0 686 433" preserveAspectRatio="none" aria-hidden>
        <circle cx="343" cy="793" r="458" fill="none" stroke="#d8a61f" strokeOpacity=".5" strokeWidth="1.2" />
        <circle cx="343" cy="793" r="400" fill="none" stroke="#d8a61f" strokeOpacity=".3" strokeWidth="1.2" />
      </svg>
      <h2 className="text-center uppercase text-[#f2ede4]" style={{ ...P(0, 75, 686), fontSize: u(27), lineHeight: u(33), letterSpacing: "-0.05em" }}>
        Voices of people who value<br />quality over compromise
      </h2>
      <div className="reviews-track flex" style={{ ...P(0, 198), gap: u(22) }}>
        {loop.map((r, i) => <ReviewCard key={i} {...r} />)}
      </div>
    </section>
  );
}
