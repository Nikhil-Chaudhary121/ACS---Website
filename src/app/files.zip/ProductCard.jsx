"use client";
import { motion } from "framer-motion";
import { u, P } from "@/lib/u";

export default function ProductCard({ index, name, price, img, fs }) {
  return (
    <motion.article
      variants={{ hidden: { opacity: 0, y: 40 }, show: { opacity: 1, y: 0 } }}
      whileHover={{ y: -8 }}
      className="overflow-hidden bg-[#f1bf20] text-[#2b2b2b]"
      style={{ ...P(26 + index * 161, 76, 143, 143), borderRadius: u(10) }}
    >
      <h3 className="absolute" style={{ left: u(14), top: u(9), fontSize: u(fs), lineHeight: 1.1, letterSpacing: "-0.05em" }}>{name}</h3>
      <p className="absolute" style={{ left: u(14), top: u(24), fontSize: u(12.5), lineHeight: 1.1 }}>₹{price.toLocaleString("en-IN")}</p>
      <img src={img} alt={name} className="absolute bottom-0 left-0 w-full object-contain object-bottom" style={{ height: u(112) }} />
    </motion.article>
  );
}
