"use client";
import { motion } from "framer-motion";
import Marquee from "./Marquee";
import { whyUs } from "@/data/content";
import { u, P } from "@/lib/u";

export default function WhyChoose() {
  return (
    <section id="why" className="relative z-10 w-full overflow-hidden" style={{ height: u(583) }}>
      {/* caution tapes */}
      <Marquee side="left" y={77} rot={8.4} dir={-1} />
      <Marquee side="right" y={77} rot={-6.7} dir={-1} />
      <Marquee side="left" y={83} rot={-5.8} dir={1} />
      <Marquee side="right" y={83} rot={5.4} dir={1} />

      {/* hook + cables */}
      <svg className="absolute inset-0 size-full" viewBox="0 0 686 583" preserveAspectRatio="none" aria-hidden>
        <defs>
          <pattern id="hz" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
            <rect width="4" height="8" fill="#f4c22b" /><rect x="4" width="4" height="8" fill="#111" />
          </pattern>
        </defs>
        <path d="M343 140 L72 223" stroke="#7c7c7c" strokeWidth="2.2" fill="none" />
        <path d="M343 140 L614 223" stroke="#7c7c7c" strokeWidth="2.2" fill="none" />
        <rect x="331" y="88" width="24" height="28" rx="3" fill="url(#hz)" stroke="#111" strokeWidth="1.5" />
        <ellipse cx="343" cy="126" rx="6" ry="9" fill="none" stroke="#8b8b8b" strokeWidth="2.4" />
        <rect x="336" y="134" width="14" height="8" rx="2" fill="#555" />
      </svg>

      {/* container */}
      <motion.div initial={{ y: -60, rotate: -3, opacity: 0 }} whileInView={{ y: 0, rotate: 0, opacity: 1 }} viewport={{ once: true }}
        transition={{ type: "spring", stiffness: 60, damping: 9 }} style={{ ...P(68, 222, 550, 284), transformOrigin: "50% 0%" }}>
        <div className="absolute inset-0 bg-[#131313]" />
        <div className="absolute" style={{ ...P(32, 28, 486, 230), background: `repeating-linear-gradient(90deg,#141414 0 ${u(28)},#33322f ${u(28)} ${u(36)})` }} />
        <h2 className="absolute w-full text-center font-extrabold text-white" style={{ top: u(53), fontSize: u(46), lineHeight: 1, letterSpacing: "-0.06em" }}>{whyUs.title}</h2>
        <p className="absolute text-center text-white" style={{ ...P(65, 110, 420), fontSize: u(14), lineHeight: 1.3, letterSpacing: "-0.04em" }}>{whyUs.text}</p>
      </motion.div>
    </section>
  );
}
