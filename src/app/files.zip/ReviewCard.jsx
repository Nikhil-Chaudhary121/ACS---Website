import { u } from "@/lib/u";

export default function ReviewCard({ name, age, text, tilt, avatar }) {
  return (
    <figure className="relative shrink-0 overflow-hidden border border-white/30 bg-white/10 backdrop-blur-[2px]"
      style={{ width: u(230), height: u(118), borderRadius: u(20), transform: `rotate(${tilt}deg)` }}>
      <svg className="absolute inset-0 size-full" viewBox="0 0 230 118" preserveAspectRatio="none" aria-hidden>
        <polyline points="10,110 58,84 100,98 150,58 190,70 212,34" fill="none" stroke="#f5c22b" strokeOpacity=".9" strokeWidth="9" />
        <polygon points="200,26 226,20 214,46" fill="#f5c22b" fillOpacity=".9" />
      </svg>
      <div className="absolute overflow-hidden rounded-full bg-[#d9d4cc] text-center text-[#2b2b2b]"
        style={{ left: u(14), top: u(12), width: u(32), height: u(32), fontSize: u(14), lineHeight: u(32) }}>
        {avatar ? <img src={avatar} alt={name} className="size-full object-cover" /> : name[0]}
      </div>
      <figcaption className="absolute text-right text-[#f4efe6]" style={{ right: u(16), top: u(10), fontSize: u(15), lineHeight: 1.1 }}>
        {name}<br />{age} years old
      </figcaption>
      <blockquote className="absolute text-[#eee9e0]" style={{ left: u(14), top: u(58), width: u(200), fontSize: u(8.5), lineHeight: 1.25 }}>{text}</blockquote>
    </figure>
  );
}
