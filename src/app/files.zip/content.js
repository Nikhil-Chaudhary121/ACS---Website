// Edit all text, prices and images here.
export const hero = {
  kicker: "Advanced Construction",
  title: "SPARES",
  tagline1: "Find high-quality",
  tagline2: "SPARE PARTS",
  note: "Sdfsffasfafasfdfadf", // placeholder text from the design
};

export const navLinks = [
  { label: "Home", href: "#" },
  { label: "Most selling", href: "#selling" },
  { label: "Brands", href: "#brands" },
  { label: "Why us", href: "#why" },
  { label: "Reviews", href: "#reviews" },
];

// slides shown in the "Brand that Trust Quality" card. Add img: "/brands/x.png" for a real logo.
export const brandSlides = [
  { name: "BRAND LOGO", img: "" },
  { name: "BRAND LOGO 2", img: "" },
  { name: "BRAND LOGO 3", img: "" },
  { name: "BRAND LOGO 4", img: "" },
];

// fs = name font size (design units)
export const products = [
  { id: 1, name: "Mining Machinery", price: 100, img: "/p1.png", fs: 12.5 },
  { id: 2, name: "IDLER PIN", price: 1056, img: "/p2.png", fs: 12.5 },
  { id: 3, name: "Steel Precision", price: 5000, img: "/p3.png", fs: 12.5 },
  { id: 4, name: "Sss Clutch Motor Pulley 70mm", price: 150, img: "/p4.png", fs: 10.5 },
];

export const brands = ["B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8"];

export const whyUs = {
  title: "WHY CHOOSE US?",
  text: "We provide high-quality spare parts that help keep your machinery running smoothly and efficiently. With a wide range of reliable components, competitive pricing, and dependable service, we make it easier to find the right parts for your equipment. Our focus on quality, durability, and customer satisfaction ensures you get parts you can rely on when it matters most.",
};

// tilt = card rotation in degrees, avatar = "/avatars/x.jpg" (initial letter shown if empty)
export const reviews = [
  { id: 1, name: "Andri", age: 30, tilt: -16, avatar: "", text: "Fairly priced, and excellent from start to finish." },
  { id: 2, name: "Julia", age: 28, tilt: -8, avatar: "", text: "Great quality and reliable parts. We found exactly what we needed, and the entire process was quick and hassle-free." },
  { id: 3, name: "George", age: 26, tilt: 5.5, avatar: "", text: "Finding the right spare part was easy and the team was very helpful throughout the service. Highly satisfied with the service." },
  { id: 4, name: "Amara", age: 34, tilt: 14, avatar: "", text: "We've been sourcing spare parts for our machines and have always received great products and helpful support." },
];
