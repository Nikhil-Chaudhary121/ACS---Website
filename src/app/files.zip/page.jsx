import Hero from "@/components/Hero";
import Trust from "@/components/Trust";
import MostSelling from "@/components/MostSelling";
import Brands from "@/components/Brands";
import WhyChoose from "@/components/WhyChoose";
import Testimonials from "@/components/Testimonials";
import { u } from "@/lib/u";

export default function Page() {
  return (
    <main className="w-full overflow-hidden">
      <Hero />
      <Trust />
      <MostSelling />

      {/* Brands + Why choose us share one yellow background and the curved dark band */}
      <div className="relative w-full overflow-hidden bg-linear-to-br from-[#fcd95e] to-[#f2bf22]" style={{ height: u(830) }}>
        <svg className="absolute inset-0 size-full" viewBox="0 0 686 830" preserveAspectRatio="none" aria-hidden>
          <path d="M690 27 Q520 247 0 267" fill="none" stroke="rgba(0,0,0,.35)" strokeWidth="38" />
        </svg>
        <Brands />
        <WhyChoose />
      </div>

      <Testimonials />
    </main>
  );
}
