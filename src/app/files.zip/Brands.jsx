"use client";
import { motion } from "framer-motion";
import { brands } from "@/data/content";
import { u, P } from "@/lib/u";

export default function Brands() {
  return (
    <section id="brands" className="relative z-10 w-full" style={{ height: u(247) }}>
      <h2 className="absolute font-medium text-[#2b2b2b]" style={{ ...P(48, 15), fontSize: u(40), lineHeight: 1, letterSpacing: "-0.06em" }}>Shop by Brands</h2>
      {brands.map((b, i) => {
        const row = i < 4 ? 0 : 1;
        const x = (row ? 26 : 39) + (i % 4) * 158;
        return (
          <motion.button key={b}
            initial={{ opacity: 0, scale: 0.85 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}
            transition={{ delay: i * 0.05, type: "spring" }}
            whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.95 }}
            className="bg-[#fdf3e3] text-black"
            style={{ ...P(x, row ? 161 : 96, 145, 50), borderRadius: u(14), fontSize: u(38), lineHeight: u(50), letterSpacing: "-0.05em" }}>
            {b}
          </motion.button>
        );
      })}
    </section>
  );
}
