"use client";
import { motion } from "framer-motion";
import ProductCard from "./ProductCard";
import { products } from "@/data/content";
import { u, P } from "@/lib/u";

export default function MostSelling() {
  return (
    <section id="selling" className="relative w-full bg-[#2a2a2a] text-[#efe9df]" style={{ height: u(253) }}>
      <h2 className="absolute font-medium" style={{ ...P(48, 14), fontSize: u(40), lineHeight: 1, letterSpacing: "-0.06em" }}>Most Selling</h2>
      <a href="#" className="absolute text-[#9d9a94]" style={{ ...P(523, 29), fontSize: u(16), lineHeight: 1 }}>Browse all</a>
      <span className="absolute bg-[#8b8883]" style={P(523, 47, 96, 1)} />
      <motion.div className="absolute inset-0" initial="hidden" whileInView="show" viewport={{ once: true, margin: "-80px" }} transition={{ staggerChildren: 0.12 }}>
        {products.map((p, i) => <ProductCard key={p.id} index={i} {...p} />)}
      </motion.div>
      <span className="absolute bg-white/30" style={P(20, 241, 645, 1)} />
    </section>
  );
}
