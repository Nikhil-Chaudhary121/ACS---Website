"use client";
import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { gsap } from "gsap";
import { animate, stagger } from "animejs";
import { hero, navLinks } from "@/data/content";
import { u, P } from "@/lib/u";

export default function Hero() {
  const ref = useRef(null);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const float = animate(".float-sq", { y: [-6, 6], alternate: true, loop: true, duration: 1800, ease: "inOutSine", delay: stagger(300) });
    const ctx = gsap.context(() => {
      gsap.from(".hero-line", { yPercent: 110, duration: 1, stagger: 0.12, ease: "power4.out" });
      gsap.from(".hero-machine", { x: 160, opacity: 0, duration: 1.4, ease: "power3.out", delay: 0.2 });
      gsap.from(".hero-fade", { opacity: 0, y: 16, duration: 0.8, stagger: 0.1, delay: 0.8 });
    }, ref);
    return () => { float.pause(); ctx.revert(); };
  }, []);

  return (
    <section ref={ref} className="relative w-full overflow-hidden bg-linear-to-br from-[#fde28a] to-[#f6c02a] text-[#2b2b2b]" style={{ height: u(438) }}>
      {/* hamburger */}
      <button onClick={() => setOpen(!open)} aria-label="Menu"
        className={`z-[60] flex flex-col items-center justify-center transition-colors ${open ? "text-[#fff3e2]" : "text-[#2b2b2b]"}`}
        style={{ ...P(641, 10, 24, 24), gap: u(3.6) }}>
        {[0, 1, 2].map((i) => <span key={i} className="block bg-current" style={{ width: u(13), height: u(1.3) }} />)}
      </button>
      <AnimatePresence>
        {open && (
          <motion.nav
            initial={{ clipPath: "circle(0% at 95% 5%)" }} animate={{ clipPath: "circle(150% at 95% 5%)" }}
            exit={{ clipPath: "circle(0% at 95% 5%)" }} transition={{ duration: 0.6, ease: [0.76, 0, 0.24, 1] }}
            className="fixed inset-0 z-50 flex flex-col items-center justify-center gap-5 bg-[#2a2a2a] text-[#fff3e2]">
            {navLinks.map((l) => (
              <a key={l.label} href={l.href} onClick={() => setOpen(false)} className="text-5xl font-medium tracking-[-0.06em] hover:text-[#f7c325] md:text-7xl">{l.label}</a>
            ))}
          </motion.nav>
        )}
      </AnimatePresence>

      {/* title */}
      <div className="overflow-hidden" style={{ ...P(50, 58, 260, 24), fontSize: u(21), lineHeight: 1.15, letterSpacing: "-0.06em" }}>
        <div className="hero-line">{hero.kicker}</div>
      </div>
      <div className="overflow-hidden" style={{ ...P(50, 80, 260, 62), fontSize: u(55), lineHeight: 1.08, letterSpacing: "-0.06em" }}>
        <div className="hero-line">{hero.title}</div>
      </div>

      {/* right tagline */}
      <div className="hero-fade bg-[#2b2b2b]" style={P(436, 69, 46, 4)} />
      <div className="hero-fade" style={{ ...P(455, 86), lineHeight: 1.08, letterSpacing: "-0.06em" }}>
        <div style={{ fontSize: u(18) }}>{hero.tagline1}</div>
        <div style={{ fontSize: u(22) }}>{hero.tagline2}</div>
      </div>

      {/* machine (put a tightly cropped excavator.png in /public) */}
      <img src="/excavator.png" alt="Yellow excavator arm" className="hero-machine z-0 max-w-none" style={P(95, 112, 467)} />

      {/* glass squares */}
      <span className="float-sq z-10 bg-white/35 backdrop-blur-sm" style={P(384, 144, 66, 66)} />
      <span className="float-sq z-10 bg-white/40 backdrop-blur-sm" style={P(222, 222, 66, 66)} />

      {/* cream pill */}
      <motion.a href="#selling" aria-label="Shop spare parts" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.96 }}
        className="hero-fade z-10 bg-[#fff3e2]" style={{ ...P(522, 158, 128, 32), borderRadius: u(11) }} />

      {/* checker squares */}
      <div className="hero-fade z-10 grid grid-cols-2 grid-rows-2" style={P(601, 338, 35, 33)}>
        <span className="bg-[#2b2b2b]" /><span /><span /><span className="bg-[#2b2b2b]" />
      </div>

      {/* L-shaped line + note */}
      <div className="hero-fade z-10 border-b border-r border-[#2b2b2b]" style={P(129, 316, 128, 53)} />
      <p className="hero-fade" style={{ ...P(34, 382), fontSize: u(15), fontWeight: 300, lineHeight: 1.2, letterSpacing: "-0.02em" }}>{hero.note}</p>
    </section>
  );
}
