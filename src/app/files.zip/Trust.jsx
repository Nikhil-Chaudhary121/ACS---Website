"use client";
import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { brandSlides } from "@/data/content";
import { u, P } from "@/lib/u";

gsap.registerPlugin(ScrollTrigger);

const lorem = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. ";
const variants = {
  enter: (d) => ({ x: d * 80, opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: (d) => ({ x: -d * 80, opacity: 0 }),
};
const ring = "absolute grid place-items-center rounded-full border-[#d1a32a] text-[#d1a32a] transition-colors hover:bg-[#d1a32a] hover:text-[#2a2a2a]";

export default function Trust() {
  const ref = useRef(null);
  const [[i, dir], setSlide] = useState([0, 1]);
  const go = (d) => setSlide(([c]) => [(c + d + brandSlides.length) % brandSlides.length, d]);

  // autoplay; the timer restarts on every slide change, including arrow clicks
  useEffect(() => {
    const t = setInterval(() => go(1), 3500);
    return () => clearInterval(t);
  }, [i]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const st = { trigger: ref.current, start: "top bottom", end: "bottom top", scrub: 1 };
      gsap.fromTo(".trust-l", { xPercent: 6 }, { xPercent: -6, ease: "none", scrollTrigger: st });
      gsap.fromTo(".trust-r", { xPercent: -6 }, { xPercent: 6, ease: "none", scrollTrigger: st });
      gsap.fromTo(".logo-card", { rotate: 9 }, { rotate: 19, ease: "none", scrollTrigger: st });
    }, ref);
    return () => ctx.revert();
  }, []);

  const slide = brandSlides[i];

  return (
    <section ref={ref} className="relative w-full overflow-hidden bg-linear-to-b from-[#5d5b56] to-[#2a2a2a]" style={{ height: u(622) }}>
      <div className="rounded-full bg-white/25 backdrop-blur-sm" style={P(54, 27, 102, 102)} />

      {/* #01 card */}
      <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} style={P(398, 28, 252, 120)}>
        <div className="bg-[#fff3e2]" style={{ ...P(0, 0, 252, 74), borderRadius: u(22) }} />
        <div className="bg-[#fff3e2]" style={{ ...P(74, 62, 178, 58), borderRadius: u(22) }} />
        <div className="font-medium" style={{ ...P(10, 14), fontSize: u(40), lineHeight: 1, letterSpacing: "-0.06em" }}>#01</div>
        <div className="font-medium" style={{ ...P(86, 18), fontSize: u(14.5), lineHeight: 1.1, letterSpacing: "-0.05em" }}>High-Quality Spare Parts</div>
        <div style={{ ...P(87, 38), fontSize: u(10), lineHeight: 1.1, letterSpacing: "-0.05em" }}>Everything You Need, In One Place</div>
        <p className="opacity-80" style={{ ...P(88, 58, 150), fontSize: u(7.5), lineHeight: 1.2 }}>From hydraulic components to engine and mechanical parts, find the right replacement parts for your machine.</p>
      </motion.div>

      {/* big headline */}
      <div className="absolute w-full text-center font-medium" style={{ top: u(220), fontSize: u(103), lineHeight: u(110), letterSpacing: "-0.055em" }}>
        <div className="trust-l text-[#cfa42d]">Brand that</div>
        <div className="trust-r"><span className="text-[#d4cfc8]">Trust </span><span className="text-[#d8a91f]">Quality</span></div>
      </div>

      {/* brand card */}
      <div className="logo-card" style={P(237, 182, 170, 350)}>
        <AnimatePresence mode="wait" custom={dir}>
          <motion.div key={i} custom={dir} variants={variants} initial="enter" animate="center" exit="exit" transition={{ duration: 0.3 }}
            className="relative size-full overflow-hidden bg-[#fff1df]" style={{ borderRadius: u(22) }}>
            <p className="text-justify text-[#f6b243]" style={{ padding: u(14), fontSize: u(11), lineHeight: 1.15 }}>{lorem.repeat(4)}</p>
            <div className="absolute inset-0 grid place-items-center text-center font-extrabold text-[#f39a12]" style={{ fontSize: u(24) }}>
              {slide.img ? <img src={slide.img} alt={slide.name} className="max-h-full max-w-full object-contain" /> : slide.name}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* arrows */}
      <motion.button aria-label="Previous brand" onClick={() => go(-1)} whileTap={{ scale: 0.9 }} className={ring}
        style={{ ...P(123, 335, 34, 34), borderWidth: u(1.3), fontSize: u(15) }}>←</motion.button>
      <motion.button aria-label="Next brand" onClick={() => go(1)} whileTap={{ scale: 0.9 }} className={ring}
        style={{ ...P(521, 335, 34, 34), borderWidth: u(1.3), fontSize: u(15) }}>→</motion.button>
      <button aria-label="Next brand" onClick={() => go(1)} className="text-[#f0ece6]" style={{ ...P(603, 438), fontSize: u(18), lineHeight: 1 }}>→</button>
    </section>
  );
}
