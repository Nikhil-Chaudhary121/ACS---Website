"use client";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { u, P } from "@/lib/u";

// One half of a caution tape. side: "left" | "right" of the hook, y: joint height, rot: tilt in degrees, dir: -1 left / 1 right
export default function Marquee({ side, y, rot, dir }) {
  const track = useRef(null);
  const left = side === "left";

  useEffect(() => {
    const t = gsap.fromTo(track.current, { xPercent: dir === -1 ? 0 : -50 }, { xPercent: dir === -1 ? -50 : 0, repeat: -1, duration: 28, ease: "none" });
    return () => t.kill();
  }, [dir]);

  return (
    <div className="overflow-hidden bg-[#141414]"
      style={{ ...P(left ? -17 : 343, y - 17, 360, 34), transformOrigin: left ? "100% 50%" : "0% 50%", transform: `rotate(${rot}deg)` }}>
      <div ref={track} className="flex h-full w-max items-center whitespace-nowrap text-[#f4c22b]" style={{ fontSize: u(15.5), letterSpacing: "-0.05em" }}>
        {Array.from({ length: 12 }).map((_, i) => <span key={i} className="shrink-0" style={{ width: u(89) }}>why choose us</span>)}
      </div>
    </div>
  );
}
