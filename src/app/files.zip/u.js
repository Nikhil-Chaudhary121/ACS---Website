// The design is a 686px-wide canvas. 1 unit = 1px of that canvas, scaled to the viewport width.
export const u = (n) => `calc(var(--u) * ${n})`;
// Absolutely position a box using coordinates measured from the design (x, y, width, height).
export const P = (x, y, w, h) => ({
  position: "absolute", left: u(x), top: u(y),
  ...(w != null && { width: u(w) }), ...(h != null && { height: u(h) }),
});
